package wspack;

import javax.ejb.Stateless;
import javax.ejb.LocalBean;

@Stateless
@LocalBean
public class SB_StringOp 
{
    public String toLower(String s)
    {//this is lowercase
        return s.toLowerCase();
    }
    
    public String toUpper(String s)
    {//THIS IS UPPERCASE
        return s.toUpperCase();
    }
    
    public String toTitle(String s)
    {//This Is Title Case
        String arr[] = s.split(" ");
        String result= "";
        String temp;
        int i, j;
        for(i =0; i< arr.length; i++)
        {
            temp = "";
            for(j =0; j< arr[i].length(); j++)
            {
                if(j == 0)
                    temp = temp + String.valueOf(arr[i].charAt(j)).toUpperCase();
                else
                    temp = temp + String.valueOf(arr[i].charAt(j)).toLowerCase();
            }//for(j...
            result = result + temp + " ";
        }//for(i...
        result = result.trim();
        return result;
    }
   
}
