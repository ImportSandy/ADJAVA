package wspack;

import javax.ejb.EJB;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "WS_StringOP")
@Stateless()
public class WS_StringOP 
{
    @EJB
    private SB_StringOp ejbRef;

    @WebMethod(operationName = "getlowerCase")
    public String getlowerCase(@WebParam(name = "s") String s) 
    {
        String str = "{" + ejbRef.toLower(s) + "}";
        return str;
    }

    @WebMethod(operationName = "getUpperCase")
    public String getUpperCase(@WebParam(name = "s") String s) 
    {
        String str = "{" + ejbRef.toUpper(s) + "}";
        return str;
    }

    @WebMethod(operationName = "getTitleCase")
    public String getTitleCase(@WebParam(name = "s") String s) 
    {
        String str = "{" + ejbRef.toTitle(s) + "}";
        return str;
    }
    
}
