package wspack;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

@WebService(serviceName = "WS_Arithmetic")
@Stateless()
public class WS_Arithmetic
{

    @WebMethod(operationName = "addition")
    public double addition(@WebParam(name = "n1") double n1, @WebParam(name = "n2") double n2) 
    {
        double ans;
        ans = n1 + n2;
        return ans;
    }

    @WebMethod(operationName = "subtraction")
    public double subtraction(@WebParam(name = "n1") double n1, @WebParam(name = "n2") double n2) 
    {
        double ans;
        ans = n1 - n2;
        return ans;
    }

    @WebMethod(operationName = "multiplication")
    public double multiplication(@WebParam(name = "n1") double n1, @WebParam(name = "n2") double n2) 
    {
        double ans;
        ans = n1 * n2;
        return ans;
    }

    @WebMethod(operationName = "division")
    public double division(@WebParam(name = "n1") double n1, @WebParam(name = "n2") double n2) 
    {
        double ans;
        ans = n1 / n2;
        return ans;
    }
    
    
        
    
    
    
}
