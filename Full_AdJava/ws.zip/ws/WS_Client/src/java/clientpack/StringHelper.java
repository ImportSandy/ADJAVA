package clientpack;

public class StringHelper 
{
    public String getlowerCase(java.lang.String s) 
    {
        clientpack1.WSStringOP_Service service = new clientpack1.WSStringOP_Service();
        clientpack1.WSStringOP port = service.getWSStringOPPort();
        return port.getlowerCase(s);
    }
    
    public String getUpperCase(java.lang.String s) 
    {
        clientpack1.WSStringOP_Service service = new clientpack1.WSStringOP_Service();
        clientpack1.WSStringOP port = service.getWSStringOPPort();
        return port.getUpperCase(s);
    }
    
    public String getTitleCase(java.lang.String s) 
    {
        clientpack1.WSStringOP_Service service = new clientpack1.WSStringOP_Service();
        clientpack1.WSStringOP port = service.getWSStringOPPort();
        return port.getTitleCase(s);
    }

    

    
    
}
