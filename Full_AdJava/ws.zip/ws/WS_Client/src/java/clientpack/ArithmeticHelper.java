package clientpack;

public class ArithmeticHelper 
{
    public double addition(double n1, double n2) 
    {
        clientpack.WSArithmetic_Service service = new clientpack.WSArithmetic_Service();
        clientpack.WSArithmetic port = service.getWSArithmeticPort();
        return port.addition(n1, n2);
    }

    public double subtraction(double n1, double n2) 
    {
        clientpack.WSArithmetic_Service service = new clientpack.WSArithmetic_Service();
        clientpack.WSArithmetic port = service.getWSArithmeticPort();
        return port.subtraction(n1, n2);
    }
    
    public double multiplication(double n1, double n2) 
    {
        clientpack.WSArithmetic_Service service = new clientpack.WSArithmetic_Service();
        clientpack.WSArithmetic port = service.getWSArithmeticPort();
        return port.multiplication(n1, n2);
    }
    
    public double division(double n1, double n2) 
    {
        clientpack.WSArithmetic_Service service = new clientpack.WSArithmetic_Service();
        clientpack.WSArithmetic port = service.getWSArithmeticPort();
        return port.division(n1, n2);
    }
    
}
