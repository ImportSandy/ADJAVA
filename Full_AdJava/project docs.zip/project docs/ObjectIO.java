/*
Serialization is the process of
converting an object into a series
of bytes.

DeSerialization is the process of
forming an object from a series of
bytes.

For serialization/deserialization
the class of the object must
implement Serializable interface.

It is an empty interface and is 
implemented for type compatiblity 
only.

ObjectOutputStream and 
ObjectInputStream classes
provide methods that can be 
used to serialize and deserialize 
objects.

tranisent fields dont get serialized.
*/

import java.io.*;

class Person implements Serializable 
{
 /*transient*/ int age;
 String name;

 Person(int a, String n)
 {
  age = a;
  name = n;
 } 

 void display()
 {
  System.out.println("name : "+ name);
  System.out.println("age : "+ age);
 }
}//Person

class ObjectIO
{
 public static void main(String args[])
 {
  try
  {
   String fname = "d:\\a.txt";

   FileOutputStream fos = new FileOutputStream(fname);//create/overwrite
   ObjectOutputStream oos = new ObjectOutputStream(fos);

   Person p1 = new Person(10 ,"vikas");
   oos.writeObject(p1);//serialize
   oos.flush();
   oos.close();

   FileInputStream fin = new FileInputStream(fname);
   ObjectInputStream ois = new ObjectInputStream(fin);
   Person p2;
   p2 = (Person) ois.readObject();//deserialize
   ois.close();
   p2.display();

   if(p1 == p2)
    System.out.println("p1 and p2 refer to same object");
  else
    System.out.println("p2 is a copy of p1");

  }//try
  catch(IOException ex)
  {
   System.out.println("Err : " +ex);
  }
  catch(ClassNotFoundException ex)
  {
   System.out.println("Err : " + ex);
  }
 }//main
}//ObjectIO