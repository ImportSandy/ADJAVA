package emppack;

import org.hibernate.Session;
import java.util.List;
import org.hibernate.Query;

public class EmpHelper 
{
    Session s;

    public EmpHelper() 
    {
        s = HibernateUtil.getSessionFactory().openSession();
    }

    public List getEmployees()
    {
        List<Emp> empList = null;
    
        try
        {
            Query q = s.createQuery("from Emp");//hql
            empList = (List<Emp>) q.list();
        }
        catch(Exception ex)
        {}
        return empList;
    }
    
    
    public void closeSession()
    {
        try
        {
            s.disconnect();
            s.close();
        }
        catch(Exception ex)
        {}
    }
    
}
