package emppack;

import java.math.BigDecimal;

public class Emp  implements java.io.Serializable 
{
     private BigDecimal eno;
     private String ename;
     private String ejob;
     private BigDecimal esal;

    public Emp() {
    }

	
    public Emp(BigDecimal eno) {
        this.eno = eno;
    }
    public Emp(BigDecimal eno, String ename, String ejob, BigDecimal esal) {
       this.eno = eno;
       this.ename = ename;
       this.ejob = ejob;
       this.esal = esal;
    }
   
    public BigDecimal getEno() {
        return this.eno;
    }
    
    public void setEno(BigDecimal eno) {
        this.eno = eno;
    }
    public String getEname() {
        return this.ename;
    }
    
    public void setEname(String ename) {
        this.ename = ename;
    }
    public String getEjob() {
        return this.ejob;
    }
    
    public void setEjob(String ejob) {
        this.ejob = ejob;
    }
    public BigDecimal getEsal() {
        return this.esal;
    }
    
    public void setEsal(BigDecimal esal) {
        this.esal = esal;
    }

}


