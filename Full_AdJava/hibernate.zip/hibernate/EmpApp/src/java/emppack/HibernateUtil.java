package emppack;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil 
{

    private static SessionFactory sessionFactory;
    
    static 
    {
        try 
        {
            // Create the SessionFactory from standard (hibernate.cfg.xml) config file.
            Configuration conf = new Configuration();
            conf.configure("/emppack/hibernate.cfg.xml");
            ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(conf.getProperties()). buildServiceRegistry();
            sessionFactory = conf.buildSessionFactory(serviceRegistry);

        } 
        catch (Exception ex) 
        {
            System.err.println("Initial SessionFactory creation failed." + ex);
        }
    }
    
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
