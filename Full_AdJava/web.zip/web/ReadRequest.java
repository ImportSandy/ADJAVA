import java.io.*;
import java.net.*;

class ReadRequest
{
 public static void main(String args[])
 {
  try
  {
   //open port : 1234
   ServerSocket ss = new ServerSocket(1234);

   boolean flag = true;

   while(flag)
   {
   //recevie  connections
   Socket s = ss.accept(); 
   //Using the socket perform IO
   InputStream in = s.getInputStream();
   OutputStream out = s.getOutputStream();

   while(in.available() > 0)
   {
    System.out.write(in.read());//fetch a byte
   }//while
   System.out.flush();
   out.write("HACKED".getBytes());
   out.flush();
   s.close();//close the connection
   }//while
   ss.close();//close the port

  }
  catch(Exception ex)
  {
   System.out.println("Err : " + ex);
  }
 }//main
}//ReadRequest