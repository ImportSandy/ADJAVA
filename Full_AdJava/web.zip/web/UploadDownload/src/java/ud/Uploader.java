package ud;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Uploader extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    { //service -> doGet/doPost -> processRequest
        
        int flag = 0;
        try
        {
            //fetch the servlets input stream from reading the transmission
            ServletInputStream sin;
            sin  = request.getInputStream();

            //ensure the directory exists
            File f = new File("c:\\advJava\\web");
            f.mkdirs();
            //open a local file for writing the received content
            
            FileOutputStream fout = new FileOutputStream("c:\\advJava\\web\\uploaded.txt");
            /*
            int data;
            while((data = sin.read()) != -1)
            {
                fout.write(data);
            }
            */

            int x;
            byte buff[] = new byte[1024];
            while((x = sin.read(buff)) != -1)
            {
                fout.write(buff);
            }
            fout.flush();
            fout.close();
            flag = 1;
        }
        catch(Exception ex)
        {
            flag = 0;
        }
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        //output of Header
        RequestDispatcher rd = request.getRequestDispatcher("Header");
        rd.include(request, response);
        //done

        //access the Servlet Context
        ServletContext context = getServletContext();
        //fetch context init parameter
        String dvlpr = context.getInitParameter("Developer");
        //fetch an attribute
        String cp = context.getAttribute("date").toString();
        
        //use the fetched values
        out.println("<h1>Developer : "+ dvlpr+"<h1>");
        out.println("<h1>Copyright : " + cp);
        
        if(flag == 1)
            out.println("<h1>File Uploaded<h1>");
        else
            out.println("<h1>File Upload Failed<h1>");
        
        out.println("<h1><a href = \"index.html\">HOME</a><h1>");
        
        out.println("</body>");
        out.println("</html>");
        out.flush();
        out.close();
    }   
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
