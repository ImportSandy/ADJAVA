package ud;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.zip.*;

public class FetchZip extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    { //service -> doGet/doPost -> processRequest
        //compress and transfer the content
        File f = new File("C:\\advJava\\web\\forDownload");
        if(f.exists())
        {
            //decide the zip file name
            String dwnldName = f.getName() + ".zip";
            //set response header 
            response.setContentType("application/zip;filename=\""+dwnldName+"\"");
            
            //fetch the response output stream
            ServletOutputStream sout;
            sout = response.getOutputStream();
            
            //create a ZIP OUTPUT STREAM
            ZipOutputStream zout = new ZipOutputStream(sout);
            
            //fetch the contents of the folder
            String arr[] = f.list();
            int i;
            byte buff[] = new byte[1024];
            int x;
            File current;
            for(i =0 ; i< arr.length; i++)
            {
                //the current content
                current = new File(f, arr[i]);
                if(current.isFile())
                {
                    //create a zip entry
                    ZipEntry entry = new ZipEntry(arr[i]);
                    //register the entry
                    zout.putNextEntry(entry);
                    //read the current file and write into zout
                    FileInputStream fin = new FileInputStream(current);
                    while((x = fin.read(buff)) != -1)
                    {
                        zout.write(buff, 0,x);
                    }
                    fin.close();
                    zout.closeEntry();
                }//if
            }//for
            zout.flush();
            zout.close();
            sout.flush();
            sout.close();
        
            
        }
        else
        {
            //set response header 
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html>");
            out.println("<body>");
            out.println("<h1>Download Source Not Found</h1>");
            out.println("<h1><a href = index.html>HOME</a></h1>");
            out.println("</body>");
            out.println("</html>");
            out.flush();
            out.close();
        }
                
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
