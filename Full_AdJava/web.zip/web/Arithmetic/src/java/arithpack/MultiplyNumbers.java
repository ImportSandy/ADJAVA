package arithpack;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MultiplyNumbers extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        //fetch existing session
        HttpSession session = request.getSession(false);
                
        if(session == null)
        {//session timeout, hence fetch data again
            response.sendRedirect("index.html");
            return;
        }
        
        //fetch data from existing session
        Object o1 = session.getAttribute("n1");
        Object o2 = session.getAttribute("n2");
        
        //o1 or o2 may be null, plan and handle
        double d1, d2;
        int flag =0 ;
        d1 = d2 = 0;
        try
        {
            d1 = Double.parseDouble(o1.toString());
            d2 = Double.parseDouble(o2.toString());
        }
        catch(Exception ex)
        {
            flag = 1;
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        if(flag == 0)
        {
            double ans = d1 *d2;
            out.println("<h1> "+ d1+" * " + d2 + " = " + ans + "</h1>");
            out.println("<h2> <a href = \"NumberHandler\"> Change Process</a></h2>");
        }
        else
        {
            out.println("<h1> Input Error</h1>");
            out.println("<h2> <a href = \"index.html\"> RETRY </a></h2>");
        }
        out.println("</body>");
        out.println("</html>");
        out.flush();
        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
