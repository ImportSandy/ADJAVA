
package arithpack;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DataManager extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String s1, s2;
        s1 = request.getParameter("n1");
        s2 = request.getParameter("n2");
        
        double d1, d2;
        int flag = 0;
        
        try
        {
            d1 = Double.parseDouble(s1.trim());
            d2 = Double.parseDouble(s2.trim());
//SESSION HANDLING 
//WAY 1            
            //create a new http session
            HttpSession session = request.getSession(true);
            //put the data into http session
            session.setAttribute("n1", d1);
            session.setAttribute("n2", d2);
            
//WAY 2            
            //put the data into http cookie
            Cookie c1 = new Cookie("n1", String.valueOf(d1));
            Cookie c2 = new Cookie("n2", String.valueOf(d2));
            //put the cookie in response object
            //so that it is written at client side
            response.addCookie(c1);
            response.addCookie(c2);
        }
        catch(Exception ex)
        {
            flag = 1;
        }
        
        if(flag == 0)
        {//redirect to number handler
            response.sendRedirect("NumberHandler");
        }
        else
        {//redirect to input error page
            response.sendRedirect("InputError");
        }
        
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
