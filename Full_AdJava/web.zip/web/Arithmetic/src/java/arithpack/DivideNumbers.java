package arithpack;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DivideNumbers extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        //fetch existing session
        HttpSession session = request.getSession(false);
                
        if(session == null)
        {//session timeout, hence fetch data again
            response.sendRedirect("index.html");
            return;
        }
        
        //fetch data from http cookies
        int i, flag =0 ;
        String name, v1, v2;
        v1 = v2 = "";
        Cookie arr[] = request.getCookies();
        for(i =0; i< arr.length &&  flag <2; i++)
        {
            //fetch cookie name
            name = arr[i].getName(); 
            if(name.equals("n1"))
            {
                //fetch cookie value
                v1 = arr[i].getValue();
                flag++;
            }
            if(name.equals("n2"))
            {
                //fetch cookie value
                v2 = arr[i].getValue();
                flag++;
            }
        }//for
        if(flag < 2)
        {
            //cookie not found, hence fetch data again
            response.sendRedirect("index.html");
            return;
        }
        
        double d1, d2;
        
        d1 = d2 = 0;
        try
        {
            d1 = Double.parseDouble(v1);
            d2 = Double.parseDouble(v2);
            flag = 0;
        }
        catch(Exception ex)
        {
            flag = 1;
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<body>");
        if(flag == 0)
        {
            double ans = d1 / d2;
            out.println("<h1> "+ d1+" / " + d2 + " = " + ans + "</h1>");
            out.println("<h2> <a href = \"NumberHandler\"> Change Process</a></h2>");
        }
        else
        {
            out.println("<h1> Input Error</h1>");
            out.println("<h2> <a href = \"index.html\"> RETRY </a></h2>");
        }
        out.println("</body>");
        out.println("</html>");
        out.flush();
        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
