package sender;

import javax.naming.*;
import msender.SenderSessionBean;

public class MessageSender 
{
    SenderSessionBean objSenderSB;
    private String msg;
    
    public MessageSender()
    {}
    
    public void setMsg(String s)
    {
        msg  = s;
    }
    
    
    public boolean sendIT()
    {
        try
        {
            Context c = new InitialContext();
            objSenderSB =  (SenderSessionBean) c.lookup("java:global/JMSSender/JMSSender-ejb/SenderSessionBean!msender.SenderSessionBean");
            objSenderSB.sendJMSMessageToMsgQueue(msg);
            return true;
        }
        catch(Exception ex)
        {
            return false;
        }
    }

    
    
    
    
    
}
