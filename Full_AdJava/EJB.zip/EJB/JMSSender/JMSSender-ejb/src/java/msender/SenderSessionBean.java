package msender;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;

@Stateless
@LocalBean
public class SenderSessionBean 
{
    @Resource(mappedName = "jms/msgQueue")
    private Queue msgQueue;
    @Inject
    @JMSConnectionFactory("jms/msgQueueConnFactory")
    private JMSContext context;

    public void sendJMSMessageToMsgQueue(String messageData) 
    {
        JMSProducer producer;
        producer = context.createProducer();
        producer.send(msgQueue, messageData);
    }

}
