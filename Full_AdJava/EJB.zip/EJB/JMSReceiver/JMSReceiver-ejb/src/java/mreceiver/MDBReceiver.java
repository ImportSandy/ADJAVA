package mreceiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/msgQueue"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class MDBReceiver implements MessageListener 
{
    public MDBReceiver() {
    }
    
    @Override
    public void onMessage(Message message) 
    {
        try
        {
            System.out.println("---------GOT A MESSAGE---------");   
            TextMessage tm = (TextMessage) message;
            System.out.println("DATA : " + tm.getText());
            System.out.println("--------------------------------");   
        }
        catch(Exception ex)
        {
            System.out.println("Err : " + ex);
        }
        
    }
    
}
