package com.myapp.struts;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class DivideAction extends org.apache.struts.action.Action 
{

    private static final String SUCCESS = "success";
    private static final String ERROR = "error";

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception 
    {
        DivideActionForm daf = (DivideActionForm) form;
        
        //fetch the input
        int x = daf.getNumerator();
        int y = daf.getDenominator();
        
        //logic
        if(y > 0)
        {
            try
            {
                int z = x/y;
                daf.setErrorMessage("");
                daf.setAnswer(z);
                return mapping.findForward(SUCCESS);
            }
            catch(Exception ex)
            {
                daf.setErrorMessage(ex.getMessage());
                return mapping.findForward(ERROR);
            }
        }
        else
        {
            daf.setErrorMessage("INVALID DENOMINATOR");
            return mapping.findForward(ERROR);
        }
        
    }
}
