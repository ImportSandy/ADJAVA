package imghandling;

import java.io.*;
import javax.imageio.*;
import java.awt.image.*;
import java.awt.*;
public class TextOnImage 
{
    private File imgFile;
    
    TextOnImage(String s) throws Exception
    {
        imgFile = new File(s);
        if(!imgFile.exists())
            throw new Exception("File "+s+" Does Not Exists");
        if(!imgFile.isFile())
            throw new Exception(s+" Is Not A File");
    }
    
    void writeOnImage(String msg) throws Exception
    {
        //create a BufferedImage Object from the imgFile
        BufferedImage bImg = ImageIO.read(imgFile);
        //write hello on the image
        Graphics g= bImg.getGraphics();
        g.setFont(new Font("Comic Sans MS", Font.PLAIN, 40));
        g.setColor(Color.red);
        g.drawString(msg, 100, 100);
        //save back the image
        File target = autoGenerateOutputFileName();
        //String filter = target.getAbsolutePath().substring(s.lastIndexOf(".")+1).toUpperCase();
        String filter = target.getName().split("\\.")[1].toUpperCase();
        ImageIO.write(bImg, filter, target);
    }
    
    
    private File autoGenerateOutputFileName() throws Exception
    {
        //c:\my documents\my pictures\koala.jpg
        //c:\my documents\my pictures\koalaWithText.jpg
        String nameparts[] = imgFile.getName().split("\\."); //splits on dot
        if(nameparts.length > 2)
            throw new Exception("Illegal Name ");
        return new File(imgFile.getParent() + System.getProperty("file.separator") + nameparts[0] + "WithText." + nameparts[1]);
    }
}
