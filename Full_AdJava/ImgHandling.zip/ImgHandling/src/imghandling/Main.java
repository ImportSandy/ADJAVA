package imghandling;
public class Main 
{
    public static void main(String[] args) 
    {
       try
       {
        TextOnImage toi = new TextOnImage("C:\\Users\\Public\\Pictures\\Sample Pictures\\Koala.jpg");
        toi.writeOnImage("HELLO IMGPRO");
       }
       catch(Exception ex)
       {
           System.out.println("Err : " + ex);
           ex.printStackTrace();
       }
    }
}
