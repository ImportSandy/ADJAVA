package TagPack;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CT1 extends SimpleTagSupport 
{
    private String style;
    
/*
    This method stores the attribute value for use ahead.
*/
    public void setStyle(String style) 
    {//setter (mutator)
        this.style = style;
    }

/*
Called by the container to invoke this tag. 
This method handles all tag processing.
*/
    @Override
    public void doTag() throws JspException 
    {
        JspWriter out = getJspContext().getOut();
        
        try 
        {
            int flag = 1;
        
            //code to execute before processing of the tag content
        
            if(style.equalsIgnoreCase("bold"))
                out.println("<b>");
            else if(style.equalsIgnoreCase("italic"))
                out.println("<i>");
            else if(style.equalsIgnoreCase("underline"))
                out.println("<u>");
            else if(style.equalsIgnoreCase("all"))
                out.println("<b><i><u>");
            else
                flag = 0;
            
            
            if(flag == 1)
            {
                JspFragment f = getJspBody();
                if (f != null) 
                {
                    f.invoke(out);
                }
            }
            
            //code to execute after processing of the tag content
            if(style.equalsIgnoreCase("bold"))
                out.println("</b>");
            else if(style.equalsIgnoreCase("italic"))
                out.println("</i>");
            else if(style.equalsIgnoreCase("underline"))
                out.println("</u>");
            else if(style.equalsIgnoreCase("all"))
                out.println("</b></i></u>");
            out.println("<br>");
        } 
        catch (java.io.IOException ex) 
        {
        }
    }
    
}
