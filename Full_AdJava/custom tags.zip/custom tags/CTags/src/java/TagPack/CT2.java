package TagPack;

import java.io.*;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

public class CT2 extends BodyTagSupport {
    private String fname;
    int cnt;

    public CT2() 
    {
        super();
        cnt = 0;
    }

    public void setFname(String fname) 
    {
        this.fname = fname;
    }
    
    /**
      This method is called when the JSP engine encounters the start tag. 
      
      It returns :
      * EVAL_BODY_BUFFERED if the JSP engine should evaluate the tag body.
      * SKIP_BODY, otherwise
     */
    @Override
    public int doStartTag() throws JspException 
    {
        File f = new File(fname);
        if(!f.exists())
            return SKIP_BODY;
        if(!f.getName().endsWith("txt"))
            return SKIP_BODY;
        
        try
        {
            JspWriter out = pageContext.getOut();
            out.println("<b><pre>");
            FileReader fr = new FileReader(fname);
            
            int x;
            char arr[] = new char[512];
            while((x = fr.read(arr)) != -1)
            {
                out.write(arr, 0,x);
            }
            fr.close();
        }
        catch(IOException ex)
        {
            return SKIP_BODY;
        }
        return EVAL_BODY_BUFFERED;
    }

    /*
      This method is called after the JSP engine finished processing the tag.
      It returns :
      * EVAL_PAGE if the JSP engine should continue evaluating the JSP page
      * SKIP_PAGE otherwise
    */
    @Override
    public int doEndTag() throws JspException 
    {
        try
        {
            JspWriter out = pageContext.getOut();
            out.println("</pre></b>");
        }
        catch(IOException ex)
        {}
        return EVAL_PAGE;//rest of the page will be evaluated
        //return SKIP_PAGE;//rest of the page will be skipped
    }

    /**
     This method is called after the JSP engine processes the body content of the tag.
     It returns 
     * EVAL_BODY_AGAIN if the JSP engine should evaluate the tag body again
     * SKIP_BODY otherwise. 
     */
    @Override
    public int doAfterBody() throws JspException 
    {
        return SKIP_BODY;
    }

}
